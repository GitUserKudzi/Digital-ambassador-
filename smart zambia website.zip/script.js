/* ============================================================
   SMART ZAMBIA | DIGITAL GOVERNMENT SKILLS AMBASSADOR
   JavaScript
   ------------------------------------------------------------
   Handles all interactive behavior for the page:
     - Hero image/testimonial slider (autoplay, dots, swipe)
     - Fixed navbar scroll effect + mobile hamburger menu
     - Scroll-spy to highlight the active nav link
     - Scroll-triggered reveal animations
     - Animated statistic counters
     - Contact form validation + fake submit flow
     - Newsletter signup mini-form
     - Smooth scrolling for in-page anchor links
   Linked from index.html via <script src="script.js"></script>
   placed just before the closing </body> tag.
   ============================================================ */

  'use strict';

  /* ── SLIDER ── */
  (function() {
    const slides  = document.querySelectorAll('.slide');
    const dots    = document.querySelectorAll('.dot');
    let current   = 0;
    let timer     = null;
    const INT     = 4000;

    function goTo(i) {
      slides[current].classList.remove('active');
      dots[current].classList.remove('active');
      current = (i + slides.length) % slides.length;
      slides[current].classList.add('active');
      dots[current].classList.add('active');
    }
    function reset() {
      clearInterval(timer);
      timer = setInterval(() => goTo(current + 1), INT);
    }
    dots.forEach((d, i) => d.addEventListener('click', () => { goTo(i); reset(); }));
    const slider = document.getElementById('slider');
    let tx = 0;
    slider.addEventListener('touchstart', e => tx = e.touches[0].clientX, { passive:true });
    slider.addEventListener('touchend', e => {
      const d = tx - e.changedTouches[0].clientX;
      if (Math.abs(d) > 50) { goTo(d > 0 ? current+1 : current-1); reset(); }
    }, { passive:true });
    slider.addEventListener('mouseenter', () => clearInterval(timer));
    slider.addEventListener('mouseleave', reset);
    reset();
  })();

  /* ── NAVBAR ── */
  (function() {
    const nb  = document.getElementById('navbar');
    const hb  = document.getElementById('hamburger');
    const nl  = document.getElementById('navLinks');
    window.addEventListener('scroll', () => nb.classList.toggle('scrolled', scrollY > 60), { passive:true });
    hb.addEventListener('click', () => {
      hb.classList.toggle('open');
      nl.classList.toggle('open');
      document.body.style.overflow = nl.classList.contains('open') ? 'hidden' : '';
    });
    nl.querySelectorAll('.nav-link').forEach(l => l.addEventListener('click', () => {
      hb.classList.remove('open'); nl.classList.remove('open'); document.body.style.overflow = '';
    }));
  })();

  /* ── ACTIVE NAV ── */
  (function() {
    const secs = document.querySelectorAll('section[id]');
    const lnks = document.querySelectorAll('.nav-link');
    const obs = new IntersectionObserver(entries => {
      entries.forEach(e => {
        if (e.isIntersecting)
          lnks.forEach(l => l.classList.toggle('active', l.getAttribute('href') === '#'+e.target.id));
      });
    }, { rootMargin: '-40% 0px -55% 0px' });
    secs.forEach(s => obs.observe(s));
  })();

  /* ── SCROLL ANIMATIONS ── */
  (function() {
    const els = document.querySelectorAll('[data-animate]');
    const obs = new IntersectionObserver(entries => {
      entries.forEach((e, i) => {
        if (e.isIntersecting) {
          e.target.style.transitionDelay = `${i * 0.07}s`;
          e.target.classList.add('visible');
          obs.unobserve(e.target);
        }
      });
    }, { threshold: 0.1 });
    els.forEach(el => obs.observe(el));
  })();

  /* ── COUNTERS ── */
  (function() {
    const cels = document.querySelectorAll('.bs-num[data-count]');
    function animate(el) {
      const target = parseInt(el.dataset.count);
      const fmt    = el.dataset.format || '';
      const pre    = el.dataset.prefix || '';
      const dur    = 2000;
      const start  = performance.now();
      function step(now) {
        const p = Math.min((now - start) / dur, 1);
        const e = 1 - Math.pow(1-p, 3);
        const v = Math.floor(e * target);
        if (fmt === 'billion') el.textContent = pre + (v/1e9).toFixed(2) + 'B';
        else if (target >= 1e6) el.textContent = pre + (v/1e6).toFixed(1) + 'M+';
        else el.textContent = pre + v.toLocaleString();
        if (p < 1) requestAnimationFrame(step);
      }
      requestAnimationFrame(step);
    }
    const sec = document.querySelector('.big-stats');
    if (sec) {
      const obs = new IntersectionObserver(entries => {
        if (entries[0].isIntersecting) { cels.forEach(animate); obs.disconnect(); }
      }, { threshold: 0.3 });
      obs.observe(sec);
    }
  })();

  /* ── FORM ── */
  (function() {
    const form = document.getElementById('contactForm');
    const btn = document.getElementById('formSubmit');
    const suc = document.getElementById('formSuccess');
    if (!form || !btn) return;
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const name = document.getElementById('fname').value.trim();
      const email = document.getElementById('femail').value.trim();
      const prov = document.getElementById('fprovince').value;
      const int  = document.getElementById('finterest').value;
      const msg  = document.getElementById('fmessage').value.trim();
      if (!name||!email||!prov||!int||!msg) {
        btn.textContent = '⚠ Please fill in all fields';
        btn.style.background = '#c0392b';
        setTimeout(() => { btn.textContent = 'Send Message →'; btn.style.background = ''; }, 2500);
        return;
      }
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        btn.textContent = '⚠ Please enter a valid email';
        btn.style.background = '#c0392b';
        setTimeout(() => { btn.textContent = 'Send Message →'; btn.style.background = ''; }, 2500);
        return;
      }
      btn.textContent = 'Sending…'; btn.style.opacity = '.7'; btn.disabled = true;
      setTimeout(() => {
        btn.style.display = 'none'; suc.style.display = 'block';
        form.reset();
      }, 1500);
    });
  })();

  /* ── NEWSLETTER ── */
  (function() {
    const form = document.getElementById('newsletterForm');
    const b = document.getElementById('nlBtn');
    if (!form || !b) return;
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const inp = document.getElementById('nlEmail');
      if (!inp||!inp.value.trim()) return;
      b.textContent = '✓'; b.style.background = '#00aa55';
      inp.value = ''; inp.placeholder = 'Thank you!';
      setTimeout(() => { b.textContent = '→'; b.style.background = ''; inp.placeholder = 'your@email.com'; }, 3000);
    });
  })();

  /* ── SMOOTH SCROLL ── */
  document.querySelectorAll('a[href^="#"]').forEach(a => {
    a.addEventListener('click', function(e) {
      const t = document.querySelector(this.getAttribute('href'));
      if (t) { e.preventDefault(); window.scrollTo({ top: t.getBoundingClientRect().top + scrollY - 76, behavior:'smooth' }); }
    });
  });
